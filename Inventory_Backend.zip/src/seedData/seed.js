export const seed = {
    admins: [
      {
        email: "superadmin@gmail.com",
        password: "admin",
      },
    ]
};